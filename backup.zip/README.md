# Weather App

TITLE - Weather Application

About - Weather Application

TECHNOLOGIES USED:

- HTML5
- Google Fonts
- CSS3 with Sass
- JavaScript
- Git
